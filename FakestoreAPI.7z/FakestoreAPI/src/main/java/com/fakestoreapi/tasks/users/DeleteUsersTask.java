package com.fakestoreapi.tasks.users;

import io.restassured.http.ContentType;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Delete;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class DeleteUsersTask implements Task {
    private final String phone;
    private final Integer id;
    private final String endpoint;

    public DeleteUsersTask(String phone, Integer id, String endpoint) {
        this.phone = phone;
        this.id = id;
        this.endpoint = endpoint;
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Delete.from("phone, id")
                        .with(
                                requestSpecification -> requestSpecification
                                        .contentType(ContentType.JSON)
                        )
        );

    }
    public static DeleteUsersTask on(String phone, Integer id, String endpoint){
        return instrumented(DeleteUsersTask.class,phone,id,endpoint);
    }
}
