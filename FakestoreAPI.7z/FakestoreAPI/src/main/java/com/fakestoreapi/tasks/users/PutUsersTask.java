package com.fakestoreapi.tasks.users;

import com.fakestoreapi.models.users.PremiumUser;
import com.fakestoreapi.questions.users.BuildDataUser;
import io.restassured.http.ContentType;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Performable;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Put;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class PutUsersTask implements Task {
    private final String endPoint;


    public PutUsersTask(String endPoint) {
        this.endPoint = endPoint;

    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        PremiumUser userInfo = actor.asksFor(BuildDataUser.was());

        actor.attemptsTo(
                Put.to(endPoint)
                        .with(
                                requestSpecification -> requestSpecification
                                        .contentType(ContentType.JSON)
                                        .body(userInfo)
                        )
        );


    }
    public static Performable on(String endPoint){
        return instrumented(PutUsersTask.class, endPoint);

    }
}
