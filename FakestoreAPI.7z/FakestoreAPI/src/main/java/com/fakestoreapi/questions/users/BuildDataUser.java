package com.fakestoreapi.questions.users;

import com.fakestoreapi.models.users.Address;
import com.fakestoreapi.models.users.Geolocation;
import com.fakestoreapi.models.users.Name;
import com.fakestoreapi.models.users.PremiumUser;
import com.fakestoreapi.utils.Data;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

import java.util.Map;

public class BuildDataUser implements Question<PremiumUser> {


    @Override
    public PremiumUser answeredBy(Actor actor) {
        Map<String, String> data = Data.extractTo().get(0);
        Name name = Name.builder()
                .firstname(data.get("Primernombre"))
                .lasrname(data.get("Segundonombre"))
                .build();

        Geolocation geolocation = Geolocation.builder()
                .lat("_38.3160")
                ._long("82.1497")
                .build();

        Address address = Address.builder()
                .city("Tunja")
                .street("7835 new road")
                .number(4)
                .zipcode("12926-3875")
                .build();

        PremiumUser premiumUser = PremiumUser.builder()
                .email(data.get("Correo"))
                .username("john4")
                .password("val214")
                .name(name)
                .address(address)
                .phone("1-570-236-7033")
                .build();

        return premiumUser;
    }

    public static BuildDataUser was() {
        return new BuildDataUser();

    }
}

