package com.fakestoreapi.questions.users;

import com.fakestoreapi.models.users.PremiumUser;
import com.fakestoreapi.models.users.responseDelete.PremiumUserDelete;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class DeleteResponse implements Question<PremiumUserDelete> {

    @Override
    public PremiumUserDelete answeredBy(Actor actor) {
        return SerenityRest.lastResponse().as(PremiumUserDelete.class);
    }

    public static DeleteResponse was() {
        return new DeleteResponse();
    }
}
