package com.fakestoreapi.questions.users;

import com.fakestoreapi.models.users.PremiumUser;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class PutDataResponse implements Question<PremiumUser> {
    @Override
    public PremiumUser answeredBy(Actor actor) {
            return SerenityRest.lastResponse().as(PremiumUser.class);
    }

    public static PutDataResponse was(){
        return new PutDataResponse();
    }
}
