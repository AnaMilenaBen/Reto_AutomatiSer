package com.fakestoreapi.stepDefinitions;

import com.fakestoreapi.questions.users.PutDataResponse;
import com.fakestoreapi.tasks.users.PutUsersTask;
import io.cucumber.java.Before;
import io.cucumber.java.en.*;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.util.EnvironmentVariables;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static org.hamcrest.Matchers.equalTo;

public class PutUsersStepDef {
    private EnvironmentVariables environmentVariables;

    private String theRestApiBaseUrl;

    Actor user= Actor.named("user");

    @Before
    public void setUserBaseUrl(){
        theRestApiBaseUrl= environmentVariables.optionalProperty("restapi.baseurl")
                .orElse("https://fakestoreapi.com");
        user.whoCan(CallAnApi.at(theRestApiBaseUrl));

    }

    @When("I consume the endpoint {string} and I send the user information email {string}, firstname {string} username {string}")
    public void iConsumeTheEndpointAndISendTheUserInformationEmailFirstnameUsername(String endpoint, String email, String firstname, String lastname) {
        user.attemptsTo(
                PutUsersTask.on(endpoint)
        );

    }
    @Then("I can validate the response server {string}")
    public void iCanValidateTheResponseServer(String phoneUser) {
        String x = PutDataResponse.was().answeredBy(user).getPhone();
        user.should(
                seeThat(
                        "The server response was",
                        res-> PutDataResponse.was().answeredBy(user).getPhone(),
                        equalTo(phoneUser)


                )
        );

    }
}
