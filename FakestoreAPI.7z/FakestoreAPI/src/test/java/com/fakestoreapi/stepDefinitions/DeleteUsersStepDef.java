package com.fakestoreapi.stepDefinitions;

import com.fakestoreapi.questions.users.DeleteResponse;
import com.fakestoreapi.questions.users.PutDataResponse;
import com.fakestoreapi.tasks.users.DeleteUsersTask;
import io.cucumber.java.Before;
import io.cucumber.java.en.*;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import net.thucydides.core.util.EnvironmentVariables;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static org.hamcrest.Matchers.equalTo;

public class DeleteUsersStepDef {

    private EnvironmentVariables environmentVariables;
    private String theRestApiBaseUrl;
    Actor user= Actor.named("user");

    @Before
    public void setUserBaseUrl(){
        theRestApiBaseUrl= environmentVariables.optionalProperty("restapi.baseurl")
                .orElse("https://fakestoreapi.com");
        user.whoCan(CallAnApi.at(theRestApiBaseUrl));

    }



    @When("I consume the endpoint {string} and I send the id \"{int},phone {string}\"")
    public void iConsumeTheEndpointAndISendTheIdPhone(String endpoint, Integer id, String phone) {
        user.attemptsTo(
                DeleteUsersTask.on(phone,id,endpoint)
        );

    }
    @Then("I can validate the message {int}")
    public void iCanValidateTheMessage(Integer phone) {
        user.should(
                seeThat(
                        "The server response was",
                        res-> DeleteResponse.was().answeredBy(user).getPhone()
                        equalTo("phone")

    }
}
